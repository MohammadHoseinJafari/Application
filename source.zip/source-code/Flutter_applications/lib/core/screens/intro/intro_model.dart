import 'package:flutter/material.dart';

class IntroModel extends ChangeNotifier {}
