import 'package:flutter/material.dart';
class Constants {

}
class CustomColors {
  static var loginBgColor = Color(0xff1B293B);
  static var signUpBgColor = Color(0xff007AD9);
}
