from rest_framework import serializers
from .models import Customer

class CustomerSerializers(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = ['position_id','company_name','location','location','last','applicant' ,'job_site' , 'job_type' , 'req' , 'des' , 'phone' , 'Email']

